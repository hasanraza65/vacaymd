@include('layouts.includes.header')


@include('layouts.includes.sidebar')

@include('layouts.includes.footer')