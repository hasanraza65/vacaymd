<div class="imagecard m-2 p-3">
           <b class=""><p>Hangover Kit Instructions.</p></b>
           <p>The best way to avoid a hangover is to avoid excessive alcohol and adequate hydration</p>
           <p>*Please read information included with your kit</p>
           <img src="https://orders.vacaymd.com/src/assets/uploads/Instructions/hangover.png" width="600px" alt="">
           
</div>