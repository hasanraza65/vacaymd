<div class="imagecard m-2 p-3">
           <b class=""><p>Urinary Tract Infection (UTI) Kit Instructions.</p></b>
           <p>*Please read information included with your kit</p>
           <img src="https://orders.vacaymd.com/src/assets/uploads/Instructions/uti.png" width="600px" alt="">
           <p style="font-size:14px;">*Williams G, et al.Cranberries for preventing urinary tract infections. Cochrane Database of Systematic Reviews 2023.</p>
</div>