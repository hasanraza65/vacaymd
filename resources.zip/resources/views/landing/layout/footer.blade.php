


<script>
  /*
  function checkRequiredFields(stepSelector) {
    var missingFields = false;
    $(stepSelector).find(':input[required]').each(function() {
      if ($(this).val() === '') {
        missingFields = true;
        return false; // break the loop
      }
    });

    if (missingFields) {
      alert('Please fill in all required fields before moving to the next step.');
      return false;
    } else {
      // Code to move to the next step
      return true;
    }
  } */
</script>

 <!---sweet alerts ---> 
 <script src="/src/plugins/src/sweetalerts2/sweetalerts2.min.js"></script>
 <script src="/src/plugins/src/sweetalerts2/custom-sweetalert.js"></script>
 <!--- Ending sweet alerts --->
 <script src="/src/steps.js" crossorigin="anonymous"></script>

</body>
</html>