
<style>
    body{
        font-family: arial !important;
    }
</style>

<img src="https://vacaymd.skvclients.com/src/assets/logos/logo.png" alt="Logo" class="logo" />
         <h1>Thank you for your order</h1>