<div class="alert alert-danger alert-dismissible fade show mb-4 d-none error-message" role="alert">
        <strong>Sorry!</strong> You are not eligible for this treatment.
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
